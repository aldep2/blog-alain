// Modèle Article (exemple minimal)
class Article {
  constructor(id, titre, contenu) {
    this.id = id;
    this.titre = titre;
    this.contenu = contenu;
  }
}

module.exports = Article;
